<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel Vue App</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?> <!-- Ensure this line is present -->
</head>
<body>
    <div id="app"></div> <!-- This should match your Vue app mounting point -->
</body>
</html><?php /**PATH C:\laravel\laravel_vue\exam_project_laravel11_vue3\resources\views/welcome.blade.php ENDPATH**/ ?>