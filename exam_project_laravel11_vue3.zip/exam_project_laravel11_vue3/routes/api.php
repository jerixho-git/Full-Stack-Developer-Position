<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\UserDetailsController;
use App\Http\Controllers\TodoController;
use App\Http\Controllers\AuthController;

Route::prefix('users')
    ->middleware(['auth:api', 'admin'])
    ->group(function () {
        Route::post('/', [UserController::class, 'create']);
        Route::get('/', [UserController::class, 'index']);
        Route::get('/{id}', [UserController::class, 'show']);
        Route::put('/{id}', [UserController::class, 'update']);
        Route::delete('/{id}', [UserController::class, 'destroy']);
    });

Route::prefix('user_details')->middleware(['auth:api', 'admin'])->group(function () {
    Route::post('/', [UserDetailsController::class, 'create']);
    Route::get('/', [UserDetailsController::class, 'index']);
    Route::get('/{id}', [UserDetailsController::class, 'show']);
    Route::put('/{id}', [UserDetailsController::class, 'update']);
    Route::delete('/{id}', [UserDetailsController::class, 'destroy']);
});

Route::prefix('todos')->middleware('auth:api')->group(function () {
    Route::post('/', [TodoController::class, 'create']);
    Route::get('/', [TodoController::class, 'index']);
    Route::get('/{id}', [TodoController::class, 'show']);
    Route::put('/{id}', [TodoController::class, 'update']);
    Route::delete('/{id}', [TodoController::class, 'destroy']);
});

Route::post('/login', [AuthController::class, 'login']);