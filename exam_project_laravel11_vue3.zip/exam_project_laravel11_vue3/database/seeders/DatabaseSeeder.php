<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create a super admin user
        User::factory()->create([
            'username' => 'superadmin',
            'name' => 'Super Admin', // Add the name field
            'password' => Hash::make('superadminpassword'), // Use Hash::make to hash the password
            'usertype' => 'admin', // Set user type to admin
            'createdate' => now(),
            'updatedate' => now(),
        ]);

        // Create regular users
        User::factory()->count(10)->create([
            'password' => Hash::make('password'), // Default password for regular users
            'name' => 'Regular User', // Provide a name for regular users
        ]);
    }
}
