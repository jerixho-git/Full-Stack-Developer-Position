<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserDetail;
use Illuminate\Http\Request;
use Validator;

class UserDetailsController extends Controller
{
    public function index()
    {
        return UserDetail::all();
    }

    public function create(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'user_id' => ['required', 'exists:users,id', 'unique:user_details'],
            'firstname' => ['required', 'string'],
            'lastname' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6'],
            'email' => ['required', 'email', 'unique:user_details'],
        ]);

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);
        }

        $request->merge(['createdate' => now()]);
        $request->merge(['updatedate' => now()]);
        $userDetail = UserDetail::create($request->all());

        return response()->json($userDetail, 201);
    }

    public function show($id)
    {
        return UserDetail::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $userDetail = UserDetail::findOrFail($id);
        $validate = Validator::make($request->all(), [
            'user_id' => ['required', 'exists:users,id', 'unique:user_details,user_id,' . $userDetail->id],
            'firstname' => ['required', 'string'],
            'lastname' => ['required', 'string'],
            'password' => ['required', 'string', 'min:6'],
            'email' => ['required', 'email', 'unique:user_details,email,' . $userDetail->id],
        ]);

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);
        }

        $request->merge(['updatedate' => now()]);
        $userDetail->update($request->all());
        return response()->json($userDetail);
    }

    public function destroy($id)
    {
        $userDetail = UserDetail::findOrFail($id);
        $userDetail->delete();
        return response()->json(null, 204);
    }
}
