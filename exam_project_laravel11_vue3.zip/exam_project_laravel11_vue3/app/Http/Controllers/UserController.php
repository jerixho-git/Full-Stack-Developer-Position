<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Validator;

class UserController extends Controller
{
    public function index()
    {
        return User::all();
    }

    public function create(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'username' => ['required', 'string', 'unique:users'],
            'password' => ['required', 'string', 'min:6'],
            'usertype' => ['required', 'string', 'in:admin,user'],
        ]);

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);
        }

        $user = User::create([
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'usertype' => $request->usertype,
            'createdate' => now(),
            'updatedate' => now(),
        ]);

        return response()->json($user, 201);
    }

    public function show($id)
    {
        return User::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validate = Validator::make($request->all(), [
            'username' => ['sometimes', 'required', 'string', 'unique:users,username,' . $user->id],
            'password' => ['sometimes', 'required', 'string', 'min:6'],
            'usertype' => ['sometimes', 'required', 'string', 'in:admin,user'],
        ]);

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);
        }

        $user->username = $request->username ?? $user->username;
        $user->usertype = $request->usertype ?? $user->usertype;
        $user->updatedate = now();

        if ($request->password) {
            $user->password = Hash::make($request->password);
        }

        $request->merge(['updatedate' => now()]);
        $user->save();

        return response()->json($user);
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json(null, 204);
    }
}
