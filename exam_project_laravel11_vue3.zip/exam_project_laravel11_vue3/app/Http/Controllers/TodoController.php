<?php

namespace App\Http\Controllers;

use App\Models\Todo; // Ensure you have this model
use Illuminate\Http\Request;
use App\Enums\TaskStatus;
use Illuminate\Validation\Rules\Enum;
use Validator;

class TodoController extends Controller
{

    // Fetch all todos
    public function index()
    {
        return Todo::where('user_id', '=', auth()->id())->get();
    }

    // Create a new todo
    public function create(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'todo' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);
        }

        $request->merge(['createdate' => now()]);
        $request->merge(['updatedate' => now()]);
        $request->merge(['user_id' => auth()->id()]);
        $todo = Todo::create($request->all());
        return response()->json($todo, 201);
    }

    // Fetch a specific todo by ID
    public function show($id)
    {
        return Todo::findOrFail($id);
    }

    // Update a specific todo by ID
    public function update(Request $request, $id)
    {
        $todo = Todo::findOrFail($id);
        $validate = Validator::make(
            $request->all(),
            [
                'todo' => ['required', 'string', 'max:255'],
                'description' => ['nullable', 'string', 'max:255'],
            ]
        );

        if ($validate->fails()) {
            return response()->json([['error' => true, 'message' => 'validation error', 'fields' => $validate->errors()->messages()], 422]);

        }

        $request->merge(['updatedate' => now()]);
        $request->merge(['user_id' => auth()->id()]);
        $todo->update($request->all());
        return response()->json($todo);
    }

    // Delete a specific todo by ID
    public function destroy($id)
    {
        $todo = Todo::findOrFail($id);
        $todo->delete();
        return response()->json(null, 204);
    }
}