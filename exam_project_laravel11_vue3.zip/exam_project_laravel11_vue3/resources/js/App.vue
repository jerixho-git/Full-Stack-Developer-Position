<template>
    <div id="app">
        <Navbar /> <!-- Include your Navbar here -->
        <router-view></router-view> <!-- This is where the routed components will be rendered -->
    </div>
</template>

<script>
import Navbar from './components/Navbar.vue';

export default {
    components: {
        Navbar,
    },
};
</script>