import { createRouter, createWebHashHistory } from 'vue-router';
import Home from './components/Home.vue';
import Login from './components/Login/Login.vue';
import UserDashboard from './components/User/User.vue';
import TodoList from './components/TodoList/TodoList.vue';
import useAuth from './composables/useAuth';

const routes = [
    {
        path: '/login',
        name: 'Login',
        component: Login,
        meta: { requiresAuth: false },
    },

    {
        path: '/',
        children: [
            {
                path: '/user',
                name: 'UserDashboard',
                component: UserDashboard,
                meta: { requiresAuth: true },
                // , isAdmin: true 
            },
            {
                path: '/todos',
                name: 'TodoList',
                component: TodoList,
                meta: { requiresAuth: true },
            },
        ],
    },
];

const router = createRouter({
    history: createWebHashHistory(),
    routes,
});

// Route guard
router.beforeEach(async (to, from, next) => {
    const { user, isAuthenticated } = useAuth();

    // Check if token exists in localStorage
    const token = localStorage.getItem('token');

    if (token) {
        isAuthenticated.value = true; // Set authenticated status
        try {
            // If the user is stored in token, decode it here
            const userData = parseJwt(token); // Ensure `parseJwt` is defined elsewhere
            user.value = userData; // Set user data from token
        } catch (error) {
            console.error("Error decoding token:", error);
            isAuthenticated.value = false;
            user.value = null;
        }
    } else {
        isAuthenticated.value = false;
        user.value = null;
    }

    // Check if the route requires authentication and user is not authenticated
    if (to.matched.some(record => record.meta.requiresAuth) && !isAuthenticated.value) {
        return next({ name: 'Login' });
    }

    // Check if the route requires admin rights and user is not an admin
    const isAdmin = isAuthenticated.value && user.value?.usertype === 'admin';
    if (to.matched.some(record => record.meta.isAdmin) && !isAdmin) {
        return next({ name: 'Login' });
    }

    next(); // Proceed to route if all checks pass
});

// Helper function to decode JWT (optional)
function parseJwt(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (error) {
        console.error("Error parsing JWT", error);
        return null;
    }
}

export default router;