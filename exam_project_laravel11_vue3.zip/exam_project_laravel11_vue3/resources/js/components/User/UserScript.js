import { ref } from 'vue';
import axios from 'axios';

export default {
    setup() {
        const users = ref([]);
        const currentUser = ref({ id: null, username: '', password: '', usertype: 'user' });
        const showEditUserForm = ref(false);

        const fetchUsers = async () => {
            try {
                const response = await axios.get('/api/users', {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                users.value = response.data;
            } catch (error) {
                console.error(error);
            }
        };

        const addUser = async () => {
            try {
                await axios.post('/api/users', currentUser.value, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                resetForm();
                fetchUsers();
            } catch (error) {
                console.error(error);
            }
        };

        const deleteUser = async (id) => {
            try {
                await axios.delete(`/api/users/${id}`, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                fetchUsers();
            } catch (error) {
                console.error(error);
            }
        };

        const editUser = (user) => {
            currentUser.value = { ...user };
            showEditUserForm.value = true;
        };

        const updateUser = async () => {
            try {
                await axios.put(`/api/users/${currentUser.value.id}`, currentUser.value, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                resetForm();
                fetchUsers();
            } catch (error) {
                console.error(error);
            }
        };

        const resetForm = () => {
            currentUser.value = { id: null, username: '', password: '', usertype: 'user' };
            showEditUserForm.value = false;
        };

        fetchUsers();

        return {
            users,
            currentUser,
            showEditUserForm,
            addUser,
            deleteUser,
            editUser,
            updateUser,
            resetForm,
        };
    },
};