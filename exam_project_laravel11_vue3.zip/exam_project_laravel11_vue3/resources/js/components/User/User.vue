<template>
    <div class="container mt-5">
        <h2 class="text-center mb-4">User</h2>

        <div class="d-flex">
            <!-- User Form -->
            <div class="flex-fill me-3">
                <div class="card p-4 shadow-sm">
                    <h4>{{ showEditUserForm ? 'Edit User' : 'Add User' }}</h4>
                    <form @submit.prevent="showEditUserForm ? updateUser() : addUser()">
                        <div class="mb-3">
                            <label for="Username" class="form-label">Username</label>
                            <input v-model="currentUser.username" type="text" class="form-control"
                                placeholder="Enter username" required />
                        </div>
                        <div class="mb-3">
                            <label for="Password" class="form-label">Password</label>
                            <input v-model="currentUser.password" type="password" class="form-control"
                                placeholder="Enter password" />
                        </div>
                        <div class="mb-3">
                            <label for="Status" class="form-label">Status</label>
                            <select v-model="currentUser.usertype" class="form-select">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">
                            {{ showEditUserForm ? 'Update User' : 'Add User' }}
                        </button>
                    </form>
                </div>
            </div>

            <!-- User List -->
            <div class="flex-fill">
                <ul class="list-group">
                    <li v-for="user in users" :key="user.id"
                        class="list-group-item d-flex justify-content-between align-items-center">
                        {{ user.username }} ({{ user.usertype }})
                        <div>
                            <button @click="editUser(user)" class="btn btn-outline-warning btn-sm me-2">Edit</button>
                            <button @click="deleteUser(user.id)" class="btn btn-outline-danger btn-sm">Delete</button>

                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script src="./UserScript.js"></script>
<style src="./UserStyle.css"></style>