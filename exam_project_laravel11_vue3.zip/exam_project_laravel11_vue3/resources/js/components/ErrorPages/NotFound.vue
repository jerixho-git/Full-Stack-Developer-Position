<template>
    <div>
        <h1>404 - Page Not Found</h1>
    </div>
</template>

<script>
export default {
    name: 'NotFound',
};
</script>

<style>
/* Add styles if necessary */
</style>