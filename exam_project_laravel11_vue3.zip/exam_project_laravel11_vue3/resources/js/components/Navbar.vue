<template>
    <nav>
        <ul>
            <li><router-link to="/user">User</router-link></li>
            <li><router-link to="/todos">Todo List</router-link></li>
            <li v-if="isAuthenticated"><a @click.prevent="logout">Logout</a></li>
            <li v-else><router-link to="/login">Login</router-link></li>
        </ul>
    </nav>
</template>

<script>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

export default {
    name: 'Navbar',
    setup() {
        const router = useRouter();
        const isAuthenticated = ref(!!localStorage.getItem('token'));

        const logout = () => {
            localStorage.removeItem('token');
            isAuthenticated.value = false;
            router.push('/login');
        };

        return {
            isAuthenticated,
            logout,
        };
    },
};
</script>