<template>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Login</h2>
        <form @submit.prevent="handleLogin" class="border p-4 rounded shadow-sm mx-auto" style="max-width: 400px;">
            <div class="mb-3">
                <label for="Username" class="form-label">Username</label>
                <input v-model="username" type="text" class="form-control" placeholder="Username" required />
            </div>
            <div class="mb-3">
                <label for="Password" class="form-label">Password</label>
                <input v-model="password" type="password" class="form-control" placeholder="Password" required />
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
        <p v-if="error" class="text-danger text-center mt-3">{{ error }}</p>
    </div>
</template>
<script src="./LoginScript.js"></script>
<style src="./LoginStyle.css"></style>