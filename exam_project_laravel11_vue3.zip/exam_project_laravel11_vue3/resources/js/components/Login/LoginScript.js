import { ref } from 'vue';
import useAuth from '../../composables/useAuth';
import { useRouter } from 'vue-router';

export default {
    name: 'Login',
    setup() {
        const { loginUser, error, isAuthenticated } = useAuth();
        const username = ref('');
        const password = ref('');
        const router = useRouter();

        const handleLogin = async () => {
            await loginUser(username.value, password.value);
            if (isAuthenticated.value) {
                router.push('/todos'); 
            }
        };

        return {
            username,
            password,
            error,
            handleLogin,
        };
    },
};