<template>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Todo List</h2>

        <div class="d-flex">
            <!-- Form Section -->
            <div class="flex-fill me-3">
                <form @submit.prevent="submitTodo" class="card p-4 shadow-sm">
                    <h4>{{ isEditing ? 'Edit Todo' : 'Add Todo' }}</h4>
                    <div class="mb-3">
                        <label for="todo" class="form-label">Todo</label>
                        <input id="todo" v-model="todoForm.todo" type="text" class="form-control"
                            placeholder="Enter your todo" required />
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <input id="description" v-model="todoForm.description" type="text" class="form-control"
                            placeholder="Add a description (optional)" />
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select id="status" v-model="todoForm.status" class="form-select">
                            <option v-for="status in statuses" :key="status.value" :value="status.value">
                                {{ status.label }}
                            </option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-between mt-3">
                        <button type="submit" class="btn btn-success me-2">
                            <i class="bi bi-check-circle me-1"></i> {{ isEditing ? 'Update' : 'Add' }} Todo
                        </button>
                        <button type="button" v-if="isEditing" @click="resetForm" class="btn btn-outline-secondary">
                            <i class="bi bi-x-circle me-1"></i> Cancel
                        </button>
                    </div>
                </form>
            </div>

            <!-- Todo List Section -->
            <div class="flex-fill">
                <ul class="list-group">
                    <li v-for="todo in todos" :key="todo.id"
                        class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-1">{{ todo.todo }}</h5>
                            <p class="mb-0 text-muted small">{{ todo.description }}</p>
                            <small>
                                Status:
                                <span :class="getStatusClass(todo.status)">
                                    {{ todo.status.charAt(0).toUpperCase() + todo.status.slice(1) }}
                                </span>
                            </small>
                        </div>
                        <div>
                            <button @click="editTodo(todo)" class="btn btn-outline-warning btn-sm me-2">
                                <i class="bi bi-pencil-square me-1"></i> Edit
                            </button>
                            <button @click="deleteTodo(todo.id)" class="btn btn-outline-danger btn-sm">
                                <i class="bi bi-trash me-1"></i> Delete
                            </button>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
<script src="./TodoListScript.js"></script>
<style src="./TodoListStyle.css"></style>