import axios from 'axios';

export default {
    name: 'TodoList',
    data() {
        return {
            todos: [],
            todoForm: {
                id: null,
                todo: '',
                description: '',
                status: 'pending', // Default status
            },
            isEditing: false,
            statuses: [
                { value: 'pending', label: 'Pending' },
                { value: 'processing', label: 'Processing' },
                { value: 'completed', label: 'Completed' },
            ],
        };
    },
    methods: {
        async fetchTodos() {
            try {
                const response = await axios.get('/api/todos', {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                this.todos = response.data;
            } catch (error) {
                console.error('Error fetching todos:', error);
            }
        },
        async submitTodo() {
            try {
                if (this.isEditing) {
                    // Update existing todo
                    await axios.put(`/api/todos/${this.todoForm.id}`, { ...this.todoForm }, {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem('token')}`,
                        },
                    });
                } else {
                    // Add new todo
                    await axios.post('/api/todos', { ...this.todoForm }, {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem('token')}`,
                        },
                    });
                }
                this.resetForm();
                this.fetchTodos(); // Refresh the todo list
            } catch (error) {
                console.error('Error submitting todo:', error);
            }
        },
        getStatusClass(status) {
            if (status === 'completed') {
                return 'text-success'; // Green for completed
            } else if (status === 'processing') {
                return 'text-warning'; // Yellow for in progress
            } else if (status === 'pending') {
                return 'text-muted'; // Red for not started
            }
            return ''; // Fallback class
        },
        editTodo(todo) {
            this.todoForm = { ...todo };
            this.isEditing = true;
        },
        async deleteTodo(id) {
            try {
                await axios.delete(`/api/todos/${id}`, {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`,
                    },
                });
                this.fetchTodos(); // Refresh the todo list
            } catch (error) {
                console.error('Error deleting todo:', error);
            }
        },
        resetForm() {
            this.todoForm = {
                id: null,
                todo: '',
                description: '',
                status: 'pending', // Reset to default status
            };
            this.isEditing = false;
        },
    },
    mounted() {
        this.fetchTodos();
    },
};