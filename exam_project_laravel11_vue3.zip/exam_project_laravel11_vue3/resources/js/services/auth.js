import axios from 'axios';

const API_URL = 'http://localhost:8000/api/'; // Adjust the URL as necessary

export const login = async (username, password) => {
    return await axios.post(`${API_URL}login`, {
        username,
        password,
    });
};

export const logout = async () => {
    return await axios.post(`${API_URL}logout`);
};

// export const register = (username, email, password) => {
//     return axios.post(API_URL + 'register', {
//         username,
//         email,
//         password,
//     });
// };