import { ref } from 'vue';
import axios from 'axios';

const useAuth = () => {
    const error = ref(null);
    const isAuthenticated = ref(false);
    const user = ref(null);

    const loginUser = async (username, password) => {
        error.value = null;
        try {
            const response = await axios.post('/api/login', {
                username,
                password,
            });
            const token = response.data.token;
            localStorage.setItem('token', token);
            isAuthenticated.value = true;
        } catch (err) {
            error.value = 'Invalid username or password';
            console.error(err);
        }
    };

    return {
        loginUser,
        error,
        isAuthenticated,
        user,
    };
};

export default useAuth;