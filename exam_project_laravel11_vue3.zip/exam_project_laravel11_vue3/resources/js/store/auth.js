import { reactive } from 'vue';

const state = reactive({
    isAuthenticated: !!localStorage.getItem('token'),
});

const setAuthentication = (auth) => {
    state.isAuthenticated = auth;
};

const login = (token) => {
    localStorage.setItem('token', token);
    setAuthentication(true);
};

const logout = () => {
    localStorage.removeItem('token');
    setAuthentication(false);
};

export default {
    state,
    login,
    logout,
};